"""Trust & Provenance subsystem."""
