# OmniRAG / OmniGuard Local AI Assistant

An enterprise-grade Local AI Assistant featuring a **dual-lane architecture**: direct interaction with local/remote LLMs, or routed through the **OmniGuard RAG & Defense Control Plane** for high-assurance, claim-verified, and citation-audited generation.

---

## 1. System Architecture

The application is structured into two distinct execution lanes:

```text
                         ┌─────────────────────────┐
                         │   React / Vite Web UI   │
                         │   (Chat, Settings,      │
                         │    OmniGuard Status)    │
                         └────────────┬────────────┘
                                      │ HTTP / SSE
                                      ▼
                         ┌─────────────────────────┐
                         │  Node / Express Gateway │
                         │     (Port 3000)         │
                         └──────┬────────────┬─────┘
                                │            │
                      mode:     │            │ mode:
                     "direct"   │            │ "omniguard"
                                │            ▼
                                │    ┌───────────────────────────┐
                                │    │ Python OmniGuard Control  │
                                │    │ Plane (Threading HTTP)    │
                                │    │ (Port 8000)               │
                                │    │                           │
                                │    │ - Query Security          │
                                │    │ - Hybrid Retrieval        │
                                │    │ - Spectral DRS            │
                                │    │ - NLI Claim Verification  │
                                │    │ - GWCC Graph Consensus    │
                                │    │ - Chain-of-Verification   │
                                │    │ - Calibrated Abstention   │
                                │    │ - Trust Store Ledger      │
                                │    └─────────────┬─────────────┘
                                │                  │
                                ▼                  ▼
                         ┌─────────────────────────┐
                         │     Ollama Daemon       │
                         │      (Port 11434)       │
                         │ (qwen3, llama3.2, etc.) │
                         └─────────────────────────┘
```

### Lane 1: Direct Mode (`mode: "direct"`)
* **Execution Path**: React UI $\rightarrow$ Node Gateway (`/api/chat` or `/api/chat/stream`) $\rightarrow$ Provider (`OllamaProvider` / `HuggingFaceProvider`) $\rightarrow$ Model Inference.
* **Streaming**: Supports real-time Server-Sent Events (SSE) token streaming for Ollama.
* **Characteristics**: Fast, unaugmented, directly tests the underlying model's base knowledge. OmniGuard is completely bypassed.

### Lane 2: OmniGuard Mode (`mode: "omniguard"`)
* **Role**: OmniGuard is **not a standalone LLM provider**. It serves as an orchestration, security, retrieval, and claim verification control plane in front of the selected LLM.
* **Execution Path**: React UI $\rightarrow$ Node Gateway (`/api/omniguard/query`) $\rightarrow$ Python OmniGuard HTTP Service (`POST /query`) $\rightarrow$ Defense Pipeline $\rightarrow$ Target LLM (`Ollama`) $\rightarrow$ Claim-verified and citation-audited response.
* **Request-Aware Dispatch**: The user's chosen `provider` and `model` (e.g. `qwen3:latest`) are forwarded from the UI down to OmniGuard's request-aware generator closure without mutating global server state.

---

## 2. OmniGuard Multi-Stage Defense Pipeline

OmniGuard implements a multi-stage defense pipeline consisting of query security, retrieval/reliability analysis, claim/NLI and consensus analysis, followed by controlled generation, verification, citation auditing, and calibrated abstention:

```text
Query Ingestion
      ↓
[Query Security]           InjectionScreener & ParserSandbox (prompt injection & canary tokens)
      ↓
[Reliability Analysis]     DenseNeuralEmbeddingProvider & DRSEngine (Dynamic Reliability Scoring)
      ↓
[Hybrid Retrieval]         DenseRetriever (Cosine) + BM25Retriever fused via Reciprocal Rank Fusion (RRF)
      ↓
[Cross-Reranking]          CrossEncoderReranker (ms-marco-MiniLM-L-6-v2)
      ↓
[Claims & NLI Analysis]    ClaimExtractor (atomic claims) + NLIVerifier (deberta-v3 NLI entailment)
      ↓
[Graph Consensus]          EvidenceGraph + LGOConsensusAnalyzer (GWCC v2 graph clustering)
      ↓
[Controlled Generation]    PromptAssembler (strict [Doc X] citation tags & context framing)
      ↓
[Chain-of-Verification]    ChainOfVerificationEngine (CoV verification queries & revision)
      ↓
[Citation Auditing]        CitationTracker (regex citation mapping against retrieved chunks)
      ↓
[Calibrated Abstention]    CalibratedAbstentionEngine (safety refusal on low grounding/contradiction)
      ↓
[Trust Store Ledger]       PersistentTrustStore (Merkle hash-chained event audit log)
```

---

## 3. Telemetry & Verification Metrics

When OmniGuard defends a query, it produces detailed mathematical telemetry rendered directly in the UI status strip:

* **Citation Precision**: The fraction of inline citations (`[Doc X]`) that map to valid, extant retrieved chunks in the context.
* **Citation Recall**: The fraction of retrieved chunks that were actually cited in the final answer.
* **Grounding Ratio**: The fraction of cited sentences where the cited chunk strictly NLI-entails the sentence text ($P(\text{Entailment}) \ge 0.50$). A score of 0% indicates that the independent cross-encoder could not confirm semantic entailment for any cited sentence.
* **Citation Entailment Precision**: The proportion of valid citation checks that pass NLI semantic entailment.
* **CoV Grounding Score**: Claim-level support ratio ($\frac{\text{supported claims}}{\text{total claims extracted}}$) produced by the Chain-of-Verification engine.
* **Route & Generation State**: Decision states such as `STANDARD_PASS`, `SAFE_PASS`, `HIGH_RISK_QUARANTINE`, or `ABSTAIN`.

---

## 4. Tech Stack & Implementation Details

| Layer | Implementation | Technology |
|---|---|---|
| **Frontend** | `apps/web` | React 18, TypeScript, Vite, Tailwind CSS, Lucide icons |
| **API Gateway** | `apps/server` | Node.js, Express, TypeScript, tsx watch |
| **Control Plane** | `omniguard` | Python 3.11+, Standard Library `ThreadingMixIn` + `HTTPServer`, PyTorch, Hugging Face Transformers (`all-MiniLM-L6-v2`, `ms-marco-MiniLM-L-6-v2`, `nli-deberta-v3-small`) |
| **Inference** | Localhost | Ollama (`qwen3`, `llama3.2`, `gemma3`) |

---

## 5. Quickstart

### Prerequisites
- **Node.js**: v18+
- **Python**: v3.11+ with PyTorch and dependencies (`requirements.txt`)
- **Ollama**: Installed and running locally (`ollama serve`)

### 1. Start Ollama and Pull Models
```bash
ollama serve
ollama pull qwen3:latest
ollama pull llama3.2:latest
```

### 2. Start OmniGuard Python Service
From the repository root:
```bash
python -m omniguard.server
```
*Health check:* `GET http://localhost:8000/health`

### 3. Start Node Gateway & Web Frontend
In another terminal:
```bash
npm install
npm run dev
```
* Frontend: `http://localhost:5173`
* Node API: `http://localhost:3000`

---

## 6. Current Limitations & Constraints

* **Execution Model**: Direct mode supports real-time SSE token streaming (`/api/chat/stream`), but OmniGuard mode is currently **synchronous and blocking**. The pipeline must wait for draft generation, atomic claim extraction, NLI scoring, and CoV revision to finish before returning the payload.
* **Observed Latency**: OmniGuard can introduce substantial latency because defended queries may perform multiple generation, NLI classification, and verification operations. Actual latency depends heavily on hardware, model size, corpus volume, and enabled verification stages (e.g. real runs on local models can range from ~15s to >100s).
* **Provider Constraint in Defense Layer**: Direct mode supports both Ollama and Hugging Face. However, the OmniGuard Python service currently requires an Ollama backend (`provider: "ollama"`); passing `huggingface` to OmniGuard returns an explicit 400 rejection.
* **Storage Persistence**:
  * Vector embeddings (`DenseRetriever`) and audit ledger events (`PersistentTrustStore`) reside in memory by default and reset when the Python process restarts.
  * Chat history is stored in browser `localStorage`.
* **DRS Calibration Warmup**: Spectral Dynamic Reliability Scoring (`DRSEngine`) initializes in an uncalibrated state (`drs_calibrated: false`) on cold boot until sufficient corpus variance has accumulated.

---

## 7. Evidence & Verification History

* **Phase 1**: Coherent Python dependencies and import resolution.
* **Phase 2**: Request-aware dynamic model routing in Python OmniGuard without mutable pipeline state.
* **Phase 3**: End-to-end Node proxy integration and frontend telemetry mapping.
* **Runtime Baseline Audit (`runtime_rag_verification.md`)**:
  * 6 independent fresh-chat runs proved that when `mode: "direct"`, only the generic system prompt and user question are delivered to Qwen3.
  * Confirmed that Qwen3's correct RAG expansion stems from its own pre-trained weights, without any application or OmniGuard context leakage.

---

## 8. Upcoming Validation: Phase 4 Defense Testing

With the runtime baseline and clean architecture established, the next phase conducts adversarial defense testing to verify if OmniGuard defends against hallucinations, poisoned data, and ungrounded claims:

1. **Test A (Grounded Question)**: Valid corpus with direct factual match.
2. **Test B (Out-of-Corpus Question)**: Missing evidence to evaluate calibrated abstention vs. hallucination.
3. **Test C (Contradictory Documents)**: Conflicting information to evaluate evidence graph consensus (GWCC).
4. **Test D (Prompt Injection in Corpus)**: Malicious system-prompt override embedded inside retrieved context.
5. **Test E (Unsupported Expansion)**: Partially supported queries to test claim-level grounding and partial answers.